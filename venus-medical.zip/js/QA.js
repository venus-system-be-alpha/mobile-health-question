
const data = [
    {
        Question: "薬の使用の有無：血圧を下げる薬 "
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            , {
                text: "いいえ"
                , value: 2
            }

        ]
    }

    ,
    {
        Question: "薬の使用の有無：血糖を下げる薬又はインスリン注射"
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "薬の使用の有無：コレステロールや中性脂肪を下げる薬"
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "医師から、脳卒中（脳出血、脳梗塞等）にかかっているといわれたり、治療を受けたことがありますか。 "
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "医師から、心臓病（狭心症、心筋梗塞等）にかかっているといわれたり、治療を受けたことがありますか。"
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "医師から、慢性の腎不全にかかっているといわれたり、治療（人工透析）を受けたことがありますか。 "
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "医師から、貧血といわれたことがある。 "
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "現在、たばこを習慣的に吸っていますか。<p>（＊ 「現在、習慣的に喫煙している者」とは条件1と条件2を両方満たす者である</p><p>条件１：最近１ヶ月間吸っている</p><p>条件２：生涯で６ヶ月間以上吸っている、又は合計100本以上吸っている</p>"
        , Answer: [
            {
                text: "はい(条件１と条件２ 両方を満たす)"
                , value: 1
            }
            ,
            {
                text: "以前は吸っていたが、最近1ヶ月間は吸っていない<p>(条件2のみ満たす)</p>"
                , value: 2
            }
            ,
            {
                text: "いいえ(上記以外)"
                , value: 3
            }
        ]
    }

    ,
    {
        Question: "20 歳の時の体重から 10kg 以上増加している。"
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "1 回 30 分以上の軽く汗をかく運動を週 2 日以上、1 年以上実施"
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "日常生活において歩行又は同等の身体活動を 1 日 1 時間以上実施"
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "ほぼ同じ年齢の同性と比較して歩く速度が速い。"
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "食事をかんで食べる時の状態はどれにあてはまりますか。"
        , Answer: [
            {
                text: "何でもかんで食べることができる"
                , value: 1
            }
            ,
            {
                text: "歯や歯ぐき、かみあわせなど気になる部分があり、かみにくいことがある"
                , value: 2
            }
            ,
            {
                text: "ほとんどかめない"
                , value: 3
            }
        ]
    }

    ,
    {
        Question: "人と比較して食べる速度が速い。"
        , Answer: [
            {
                text: "速い"
                , value: 1
            }
            ,
            {
                text: "ふつう"
                , value: 2
            }
            ,
            {
                text: "遅い"
                , value: 3
            }
        ]
    }

    ,
    {
        Question: "就寝前の 2 時間以内に夕食をとることが週に 3 回以上ある。"
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "朝昼夕の３食以外に間食や甘い飲み物を摂取していますか。"
        , Answer: [
            {
                text: "毎日"
                , value: 1
            }
            ,
            {
                text: "時々"
                , value: 2
            }
            ,
            {
                text: "ほとんど摂取しない"
                , value: 3
            }
        ]
    }

    ,
    {
        Question: "朝食を抜くことが週に３回以上ある。"
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "お酒（日本酒、焼酎、ビール、洋酒など）を飲む頻度はどのくらいですか。<p>(※「やめた」とは、過去に月1回以上の習慣的な飲酒歴があった者のうち、最近1年以上酒類を摂取していない者)</p>"
        , Answer: [
            {
                text: "毎日"
                , value: 1
            }
            ,
            {
                text: "週5～6日"
                , value: 2
            }
            ,
            {
                text: "週3～4日"
                , value: 3
            }
            ,
            {
                text: "週1～2日"
                , value: 4
            }
            ,
            {
                text: "月に1～3日"
                , value: 5
            }
            ,
            {
                text: "月に1日未満"
                , value: 6
            }
            ,
            {
                text: "やめた"
                , value: 7
            }
            ,
            {
                text: "飲まない（飲めない）"
                , value: 8
            }
        ]
    }

    ,
    {
        Question: "<p>飲酒日の１日当たりの飲酒量</p>日本酒１合(アルコール度数15度・180ml)の目安：ビール(同5度・500ml)、焼酎(同25度・約110ml)、<p>ワイン(同14度・約180ml)、ウイスキー(同43度・60ml)、缶チューハイ(同5度・約500ml、同7度・約350ml)</p>"
        , Answer: [
            {
                text: "１合未満"
                , value: 1
            }
            ,
            {
                text: "１～２合未満"
                , value: 2
            }
            ,
            {
                text: "２～３合未満"
                , value: 3
            }
            ,
            {
                text: "３～５合未満"
                , value: 4
            }
            ,
            {
                text: "５合以上"
                , value: 5
            }
        ]
    }

    ,
    {
        Question: "睡眠で休養が十分とれている。"
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

    ,
    {
        Question: "運動や食生活等の生活習慣を改善してみようと思いますか。"
        , Answer: [
            {
                text: "改善するつもりはない"
                , value: 1
            }
            ,
            {
                text: "改善するつもりである（概ね６ケ月以内）"
                , value: 2
            }
            ,
            {
                text: "近いうちに（概ね１ケ月以内）改善するつもりであり、少しずつ始めている"
                , value: 3
            }
            ,
            {
                text: "既に改善に取り組んでいる（６ケ月未満）"
                , value: 4
            }
            ,
            {
                text: "既に改善に取り組んでいる（６ケ月以上）"
                , value: 5
            }
        ]
    }

    ,
    {
        Question: "生活習慣の改善について、これまでに特定保健指導を受けたことがありますか。"
        , Answer: [
            {
                text: "はい"
                , value: 1
            }
            ,
            {
                text: "いいえ"
                , value: 2
            }
        ]
    }

  ];
